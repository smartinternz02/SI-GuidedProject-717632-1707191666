<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Cart</name>
   <tag></tag>
   <elementGuidId>ba9caac1-40f8-4551-93b6-5c1b5bbc744f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='nav-cart-text-container']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#nav-cart-text-container</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>72e58a63-7e2c-426f-8331-bae0327bd5d9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>nav-cart-text-container</value>
      <webElementGuid>108a0829-7791-46b8-adc4-cbe5b8af739c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value> nav-progressive-attribute</value>
      <webElementGuid>eca7fd37-06d6-4c19-8e24-0ddc40b65be9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
      
         
      
      
        Cart
        
      
    </value>
      <webElementGuid>40f925fa-90d9-4669-bd1d-f3aeb33d1861</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;nav-cart-text-container&quot;)</value>
      <webElementGuid>aeeb4942-38bc-4eb3-9a92-068b4d255ecd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='nav-cart-text-container']</value>
      <webElementGuid>791eab97-2e85-4b2c-ba7c-9d95d19f4658</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//a[@id='nav-cart']/div[2]</value>
      <webElementGuid>4def655a-5fd4-4c59-afa0-643130e513da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[5]/div[2]</value>
      <webElementGuid>1e454732-5db2-4492-b3b3-73b1db620f1b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = 'nav-cart-text-container' and (text() = '
      
         
      
      
        Cart
        
      
    ' or . = '
      
         
      
      
        Cart
        
      
    ')]</value>
      <webElementGuid>39fcc388-8c8c-4d16-be73-320ef40b91cd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
